# Scripts

- `bootstrap.sh` — installs dependencies, prepares `.env`, enables git hooks.
