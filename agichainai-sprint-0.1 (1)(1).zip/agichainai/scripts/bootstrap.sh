#!/usr/bin/env bash
# One-time developer setup.
set -euo pipefail
cd "$(dirname "$0")/.."

command -v pnpm >/dev/null || corepack enable pnpm
pnpm install
cp -n .env.example .env 2>/dev/null || true
echo "Bootstrap complete. Run 'pnpm dev' to start everything."
