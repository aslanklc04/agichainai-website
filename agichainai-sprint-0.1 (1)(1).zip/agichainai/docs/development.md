# Development

## Prerequisites

- Node.js ≥ 20
- pnpm ≥ 9 (`corepack enable pnpm`)
- Docker (optional, for full-stack runs)

## Setup

```bash
./scripts/bootstrap.sh
```

## Daily commands

| Command          | Effect                                |
| ---------------- | ------------------------------------- |
| `pnpm dev`       | Start all apps/services in watch mode |
| `pnpm build`     | Build everything (Turbo-cached)       |
| `pnpm lint`      | ESLint across the workspace           |
| `pnpm typecheck` | TypeScript project-wide               |
| `pnpm test`      | Vitest across the workspace           |
| `pnpm format`    | Prettier write                        |

Scope any command with pnpm filters, e.g.
`pnpm --filter @agichainai/web dev`.

## Full stack via Docker

```bash
docker compose -f infra/docker/docker-compose.yml up --build
```

Ports: web 3000, admin 3001, dashboard 3002, playground 3003,
gateway 4000, engines 4001–4008.
