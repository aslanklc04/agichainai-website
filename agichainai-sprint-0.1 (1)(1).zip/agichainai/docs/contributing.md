# Contributing

1. Branch from `main`; one logical change per PR.
2. `pnpm lint && pnpm typecheck && pnpm test` must pass locally
   (the pre-commit hook formats staged files automatically).
3. New shared code goes into a package, never copied between apps/services.
4. New cross-service contracts require an entry in `docs/architecture.md`.
5. Scope discipline: nothing is implemented ahead of its sprint.
