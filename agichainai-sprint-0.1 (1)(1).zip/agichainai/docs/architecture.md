# Architecture — Sprint 0.1

## Shape

A Turborepo/pnpm monorepo with three layers:

| Layer       | Contents                                              | Rule                              |
| ----------- | ----------------------------------------------------- | --------------------------------- |
| `apps/`     | Next.js frontends (web, admin, dashboard, playground) | May depend on `packages/*` only   |
| `services/` | NestJS services (gateway + 8 engines)                 | May depend on `packages/*` only   |
| `packages/` | ui, types, events, config, utils                      | May depend on other packages only |

Apps and services never import each other directly. All shared knowledge is a
versioned package; all future runtime communication goes through the gateway
or the event envelope defined in `@agichainai/events`.

## Services

Each engine is an independent NestJS process with its own port (4000–4008),
its own Dockerfile, and a uniform `GET /health` endpoint returning the shared
`HealthReport` contract. In Sprint 0.1 that endpoint is the _only_ behavior —
by design.

## Decisions of record

1. **Monorepo over polyrepo** — atomic cross-cutting changes, one toolchain.
2. **Contracts-as-packages** — `types` and `events` are the only coupling
   surface between services.
3. **Health endpoint from day one** — every orchestrator (Compose today,
   Kubernetes later) probes the same path.
4. **Root-context Docker builds** — required for pnpm workspace resolution.
5. **No premature abstractions** — no ORM, no message broker, no auth library
   is chosen before the sprint that needs it.
