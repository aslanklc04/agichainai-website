import { describe, expect, it } from "vitest";
import { HealthController } from "./health.controller";

describe("HealthController (learning-engine)", () => {
  it("reports ok with the correct service name", () => {
    const report = new HealthController().getHealth();
    expect(report.status).toBe("ok");
    expect(report.service).toBe("learning-engine");
  });
});
