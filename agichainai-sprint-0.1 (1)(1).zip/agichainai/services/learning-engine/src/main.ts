import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);
  app.enableShutdownHooks();
  const port = Number(process.env.LEARNING_ENGINE_PORT ?? 4006);
  await app.listen(port);
}

void bootstrap();
