import { Controller, Get } from "@nestjs/common";
import type { HealthReport } from "@agichainai/types";

const STARTED_AT = Date.now();

@Controller("health")
export class HealthController {
  @Get()
  getHealth(): HealthReport {
    return {
      service: "decision-engine",
      status: "ok",
      version: "0.1.0",
      uptimeSeconds: Math.floor((Date.now() - STARTED_AT) / 1000),
      timestamp: new Date().toISOString(),
    };
  }
}
