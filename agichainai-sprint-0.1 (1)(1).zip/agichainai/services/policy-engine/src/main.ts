import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);
  app.enableShutdownHooks();
  const port = Number(process.env.POLICY_ENGINE_PORT ?? 4008);
  await app.listen(port);
}

void bootstrap();
