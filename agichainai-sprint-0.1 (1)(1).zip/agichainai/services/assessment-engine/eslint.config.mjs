export { default } from "@agichainai/config/eslint/nest";
