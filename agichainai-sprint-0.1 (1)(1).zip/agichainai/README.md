# AGIChainAI — Project Atlas

Engineering foundation for a platform designed to evolve into a
**Reasoning Operating System**. Sprint 0.1 contains infrastructure only:
no AI, no reasoning, no business logic.

## Layout

```
apps/        web · admin · dashboard · playground        (Next.js 15, React 19)
services/    gateway + 8 engines                          (NestJS 11)
packages/    ui · types · events · config · utils         (shared, versioned)
docs/        architecture, development, contributing
infra/       Docker Compose + per-service Dockerfiles
deployment/  reserved for k8s/Terraform (post-0.1)
scripts/     bootstrap tooling
tests/       reserved for cross-service e2e (post-0.1)
```

## Quick start

```bash
corepack enable pnpm
./scripts/bootstrap.sh   # install deps, prepare .env, enable hooks
pnpm dev                 # or: pnpm --filter @agichainai/web dev
```

See [`docs/development.md`](docs/development.md) for the full workflow.

## Quality gates

Turborepo · pnpm workspaces · TypeScript strict · ESLint 9 (flat) ·
Prettier · Husky + lint-staged · Vitest · Docker.
