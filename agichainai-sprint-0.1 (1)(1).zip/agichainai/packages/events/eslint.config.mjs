export { default } from "@agichainai/config/eslint/base";
