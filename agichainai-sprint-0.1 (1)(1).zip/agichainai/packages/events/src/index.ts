import type { ServiceName } from "@agichainai/types";

/**
 * Transport-agnostic event envelope.
 *
 * Every future inter-service message travels inside this envelope so that
 * tracing, ordering and versioning are uniform across the platform.
 * No concrete event types are defined in Sprint 0.1 by design.
 */
export interface EventEnvelope<TPayload = unknown> {
  /** Globally unique event id (UUID v7 recommended). */
  id: string;
  /** Dot-separated, versioned event name, e.g. "planning.plan.created.v1". */
  type: string;
  /** Emitting service. */
  source: ServiceName;
  /** Correlation id linking events of one logical operation. */
  correlationId: string;
  /** ISO 8601 emission time. */
  occurredAt: string;
  /** Envelope schema version. */
  specVersion: "1.0";
  payload: TPayload;
}
