/**
 * Platform-wide shared contracts.
 *
 * Sprint 0.1 intentionally ships only foundational primitives.
 * Domain models are added in later sprints, never invented here.
 */

/** Canonical identifiers of the platform services. */
export const SERVICE_NAMES = [
  "gateway",
  "runtime-engine",
  "assessment-engine",
  "decision-engine",
  "planning-engine",
  "execution-engine",
  "learning-engine",
  "memory-engine",
  "policy-engine",
] as const;

export type ServiceName = (typeof SERVICE_NAMES)[number];

/** Standard health payload every service exposes at GET /health. */
export interface HealthReport {
  service: ServiceName;
  status: "ok";
  version: string;
  uptimeSeconds: number;
  timestamp: string;
}
