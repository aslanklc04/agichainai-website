import { describe, expect, it } from "vitest";
import { cn } from "./cn";

describe("cn", () => {
  it("merges conflicting tailwind classes, last one wins", () => {
    expect(cn("p-2", "p-4")).toBe("p-4");
  });

  it("handles conditional values", () => {
    const enabled = Boolean(process.env.NEVER_SET);
    expect(cn("a", enabled && "b", "c")).toBe("a c");
  });
});
