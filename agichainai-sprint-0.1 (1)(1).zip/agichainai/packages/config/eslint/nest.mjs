import globals from "globals";
import base from "./base.mjs";

/** Flat ESLint config for NestJS services. */
export default [
  ...base,
  {
    languageOptions: { globals: { ...globals.node } },
    rules: {
      "@typescript-eslint/no-extraneous-class": "off"
    }
  }
];
