import { describe, expect, it } from "vitest";
import { invariant } from "./index";

describe("invariant", () => {
  it("passes on truthy condition", () => {
    expect(() => invariant(true, "must hold")).not.toThrow();
  });

  it("throws on falsy condition", () => {
    expect(() => invariant(false, "must hold")).toThrow(/must hold/);
  });
});
