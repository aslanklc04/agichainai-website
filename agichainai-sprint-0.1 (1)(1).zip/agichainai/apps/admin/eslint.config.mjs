export { default } from "@agichainai/config/eslint/next";
