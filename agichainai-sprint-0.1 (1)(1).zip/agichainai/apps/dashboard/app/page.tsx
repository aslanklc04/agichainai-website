export default function Page() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-3 px-6 text-center">
      <p className="font-mono text-xs tracking-widest text-muted-foreground uppercase">
        Sprint 0.1 · Foundation
      </p>
      <h1 className="text-2xl font-semibold tracking-tight">AGIChainAI Dashboard</h1>
      <p className="max-w-sm text-sm text-muted-foreground">
        Operational dashboard shell. Features arrive in later sprints.
      </p>
    </main>
  );
}
