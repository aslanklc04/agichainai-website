import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AGIChainAI Dashboard",
  description: "Operational dashboard shell. Features arrive in later sprints.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-dvh antialiased">{children}</body>
    </html>
  );
}
