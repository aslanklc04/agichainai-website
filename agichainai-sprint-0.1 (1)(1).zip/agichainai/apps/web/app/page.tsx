const NAV = [
  { href: "#vision", label: "Vision" },
  { href: "#atlas", label: "Project Atlas" },
  { href: "#architecture", label: "Architecture" },
  { href: "#research", label: "Research" },
  { href: "#docs", label: "Documentation" },
  { href: "#roadmap", label: "Roadmap" },
];

const ENGINES = [
  { name: "gateway", role: "Public entry point. Routing, auth and rate limiting." },
  { name: "runtime-engine", role: "Lifecycle of reasoning sessions." },
  { name: "assessment-engine", role: "Evaluation of situations and inputs." },
  { name: "decision-engine", role: "Selection of actions from options." },
  { name: "planning-engine", role: "Composition of multi-step plans." },
  { name: "execution-engine", role: "Execution of approved plan steps." },
  { name: "learning-engine", role: "Consolidation of feedback." },
  { name: "memory-engine", role: "Durable and working memory." },
  { name: "policy-engine", role: "Rules, guardrails and permissions." },
];

const ROADMAP = [
  {
    sprint: "0.1",
    title: "Foundation",
    status: "Current",
    detail:
      "Monorepo, shared configuration, service and application shells, containerization, quality gates. No product features.",
  },
  {
    sprint: "0.2",
    title: "Platform plumbing",
    status: "Next",
    detail: "Scope defined at sprint planning. Nothing is implemented ahead of it.",
  },
  {
    sprint: "0.3+",
    title: "Toward a Reasoning OS",
    status: "Later",
    detail: "Engines gain behavior incrementally, each behind explicit contracts.",
  },
];

function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
      {children}
    </p>
  );
}

function Section({
  id,
  eyebrow,
  title,
  children,
}: {
  id: string;
  eyebrow: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24 border-t border-border">
      <div className="mx-auto grid max-w-5xl gap-10 px-6 py-24 md:grid-cols-[220px_1fr] md:gap-16">
        <div className="space-y-3">
          <Eyebrow>{eyebrow}</Eyebrow>
          <h2 className="text-2xl font-semibold tracking-tight">{title}</h2>
        </div>
        <div className="space-y-6 text-[15px] leading-7 text-muted-foreground">{children}</div>
      </div>
    </section>
  );
}

export default function Page() {
  return (
    <>
      <header className="sticky top-0 z-10 border-b border-border bg-background/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-5xl items-center justify-between px-6">
          <a href="#top" className="font-mono text-sm font-semibold tracking-tight">
            agichain<span className="text-accent">ai</span>
          </a>
          <nav className="hidden gap-6 md:flex" aria-label="Primary">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main id="top">
        {/* Hero */}
        <section className="mx-auto max-w-5xl px-6 pb-28 pt-28 md:pt-40">
          <Eyebrow>Sprint 0.1 · Foundation initialized</Eyebrow>
          <h1 className="mt-6 max-w-3xl text-4xl font-semibold leading-[1.1] tracking-tight md:text-6xl">
            The foundation of a Reasoning Operating System.
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-8 text-muted-foreground">
            AGIChainAI is being built as infrastructure first. Before any intelligence, a platform:
            disciplined, observable, and designed to carry a decade of work.
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <a
              href="#architecture"
              className="inline-flex h-10 items-center rounded-full bg-foreground px-5 text-sm font-medium text-background transition-opacity hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
            >
              Explore the architecture
            </a>
            <a
              href="#docs"
              className="inline-flex h-10 items-center rounded-full border border-border px-5 text-sm font-medium transition-colors hover:bg-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
            >
              Read the docs
            </a>
          </div>
        </section>

        {/* Vision */}
        <Section id="vision" eyebrow="01 · Vision" title="Infrastructure before intelligence">
          <p>
            Most ambitious AI systems fail on engineering, not on ideas. AGIChainAI inverts the
            usual order: the platform — its boundaries, contracts, and quality gates — is
            established before a single reasoning capability exists.
          </p>
          <p>
            The long-term goal is a Reasoning Operating System: a substrate where assessment,
            decision, planning, execution, learning, memory, and policy operate as independent,
            replaceable services under one coherent runtime.
          </p>
        </Section>

        {/* Project Atlas */}
        <Section id="atlas" eyebrow="02 · Project Atlas" title="The map precedes the territory">
          <p>
            Atlas is the initiative that carries AGIChainAI from an empty repository to a working
            platform, one sprint at a time. Each sprint has a locked scope; nothing is implemented
            ahead of its sprint.
          </p>
          <p>
            Sprint 0.1 delivers exactly one thing: a production-grade monorepo — four applications,
            nine service shells, five shared packages — with linting, formatting, testing, git
            hooks, and containerization wired in from day one.
          </p>
        </Section>

        {/* Architecture */}
        <Section id="architecture" eyebrow="03 · Architecture" title="Nine services, one contract">
          <p>
            Every engine is an independent NestJS service behind a single gateway. Shared contracts
            live in versioned packages, so services depend on types — never on each other&apos;s
            internals.
          </p>
          <div className="overflow-x-auto rounded-lg border border-border bg-muted/50 p-6 font-mono text-[13px] leading-6 text-foreground">
            <pre aria-label="Service topology">{`apps ──────────────▶ gateway :4000
                        │
    ┌───────────┬──────┼───────┬───────────┐
runtime     assessment  decision   planning
 :4001         :4002      :4003      :4004
    └───────────┴──────┬───────┴───────────┘
execution     learning   memory     policy
 :4005         :4006      :4007      :4008`}</pre>
          </div>
          <ul className="grid gap-x-8 gap-y-3 sm:grid-cols-2">
            {ENGINES.map((e) => (
              <li key={e.name} className="text-sm leading-6">
                <span className="font-mono text-foreground">{e.name}</span>
                <span className="text-muted-foreground"> — {e.role}</span>
              </li>
            ))}
          </ul>
        </Section>

        {/* Research */}
        <Section id="research" eyebrow="04 · Research" title="Questions before answers">
          <p>
            The research track defines what each engine must eventually do — and, just as important,
            what it must never do. Findings become written contracts before they become code.
          </p>
          <p>
            No research artifacts are published yet. They will appear in the repository&apos;s{" "}
            <span className="font-mono text-foreground">docs/</span> directory as the work matures.
          </p>
        </Section>

        {/* Documentation */}
        <Section id="docs" eyebrow="05 · Documentation" title="Written down, or it didn't happen">
          <p>
            Architecture decisions, contribution rules, and development workflows are recorded in
            the repository from the first commit:
          </p>
          <ul className="space-y-2 font-mono text-sm text-foreground">
            <li>docs/architecture.md</li>
            <li>docs/development.md</li>
            <li>docs/contributing.md</li>
          </ul>
        </Section>

        {/* Roadmap */}
        <Section id="roadmap" eyebrow="06 · Roadmap" title="One locked sprint at a time">
          <ol className="space-y-8">
            {ROADMAP.map((item) => (
              <li key={item.sprint} className="grid gap-2 sm:grid-cols-[96px_1fr]">
                <div>
                  <p className="font-mono text-sm text-foreground">{item.sprint}</p>
                  <p className="font-mono text-[11px] uppercase tracking-widest text-accent">
                    {item.status}
                  </p>
                </div>
                <div>
                  <h3 className="text-base font-medium text-foreground">{item.title}</h3>
                  <p className="mt-1 text-sm leading-6">{item.detail}</p>
                </div>
              </li>
            ))}
          </ol>
        </Section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-5xl flex-col gap-4 px-6 py-12 text-sm text-muted-foreground md:flex-row md:items-center md:justify-between">
          <p className="font-mono">agichainai · Project Atlas · Sprint 0.1</p>
          <p>Built as infrastructure first.</p>
        </div>
      </footer>
    </>
  );
}
