# Infrastructure

- `docker/docker-compose.yml` — local orchestration of all apps and services.
- Every app/service owns its `Dockerfile`; build context is always the repo root
  so pnpm workspace resolution works inside the image.
