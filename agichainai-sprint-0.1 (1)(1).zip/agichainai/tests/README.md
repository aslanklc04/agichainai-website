# Tests

Test strategy for the monorepo:

- **Unit tests** live next to the code they test (`*.test.ts`), run with Vitest
  per package/service via `pnpm test`.
- **This directory** is reserved for cross-service end-to-end suites, added once
  the gateway exposes its first real route (Sprint 0.2+). Nothing is mocked or
  stubbed ahead of that.
