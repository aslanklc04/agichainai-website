# Deployment

This directory will hold environment-specific deployment definitions
(Kubernetes manifests, Helm charts, or Terraform) once a target platform
is chosen. Sprint 0.1 intentionally ships local Docker Compose only —
see `infra/docker/docker-compose.yml`.

Decision pending: orchestration target (Kubernetes vs. managed containers).
